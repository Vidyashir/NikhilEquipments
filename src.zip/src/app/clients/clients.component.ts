import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.css']
})
export class ClientsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  clients=[
    {BrandName:"Philips India Limited",BrandLogo:"assets/images/clients/Philips-India-Limited.jpg"},
    {BrandName:"Mahindra and Mahindra Ltd",BrandLogo:"assets/images/clients/Mahindra-and-Mahindra-Ltd.jpg"},
    {BrandName:"Force Motors Ltd",BrandLogo:"assets/images/clients/Force-Motors-Ltd.jpg"},
    {BrandName:"Piaggio Vehicles pvt Ltd",BrandLogo:"assets/images/clients/Piaggio-Vehicles-pvt-Ltd.jpg"},
    {BrandName:"Skoda Auto India Pvt Ltd",BrandLogo:"assets/images/clients/Skoda-Auto-India-Pvt-Ltd.jpg"},
    {BrandName:"Lucas TVS Ltd",BrandLogo:"assets/images/clients/Lucas-TVS-Ltd.jpg"},
    {BrandName:"Bank of India",BrandLogo:"assets/images/clients/Bank-of-India.jpg"},
    {BrandName:"ICICI Bank Ltd",BrandLogo:"assets/images/clients/ICICI-Bank-Ltd.jpg"},
    {BrandName:"LIC India Ltd",BrandLogo:"assets/images/clients/LIC-India-Ltd.jpg"},
    {BrandName:"Panchshil corporate park",BrandLogo:"assets/images/clients/Panchshil-corporate-park.jpg"},
    {BrandName:"Philips India Ltd",BrandLogo:"assets/images/clients/Philips-India-Ltd.jpg"},
    {BrandName:"Bharat Heavy Electricals Ltd",BrandLogo:"assets/images/clients/Bharat-Heavy-Electricals-Ltd.jpg"},
    {BrandName:"Videocon International Ltd",BrandLogo:"assets/images/clients/Videocon-International-Ltd.jpg"},
    {BrandName:"Voltas Ltd",BrandLogo:"assets/images/clients/Voltas-Ltd.jpg"},
    {BrandName:"ThyssenKrupp Industries (I) pvt. ltd",BrandLogo:"assets/images/clients/ThyssenKrupp-Industries-(I)-pvt-ltd.jpg"},
    {BrandName:"Kirloskar Oil Engines",BrandLogo:"assets/images/clients/Kirloskar-Oil-Engines.jpg"},
    {BrandName:"Alfa Laval (India) Ltd",BrandLogo:"assets/images/clients/Alfa-Laval-India-Ltd.jpg"},
    {BrandName:"Bosch Ltd",BrandLogo:"assets/images/clients/Bosch-Ltd.jpg"},
    {BrandName:"JCB Manufacturing ltd",BrandLogo:"assets/images/clients/JCB-Manufacturing-ltd.jpg"},
    {BrandName:"Kirby building systems",BrandLogo:"assets/images/clients/Kirby-building-systems.jpg"},
    {BrandName:"Sandvik Asia",BrandLogo:"assets/images/clients/Sandvik-Asia.jpg"},
    {BrandName:"Hoerbiger India pvt ltd",BrandLogo:"assets/images/clients/Hoerbiger-India-pvt-ltd.jpg"},
    {BrandName:"INA Bearing India pvt ltd",BrandLogo:"assets/images/clients/INA-Bearing-India-pvt-ltd.jpg"},
    {BrandName:"The Leela Kempinski",BrandLogo:"assets/images/clients/The-Leela-Kempinski.jpg"},
    {BrandName:"Fritolay India",BrandLogo:"assets/images/clients/Fritolay-India.jpg"},
    {BrandName:"The Oberoi",BrandLogo:"assets/images/clients/The-Oberoi.jpg"},
    {BrandName:"Harinagar Sugar Mills Ltd",BrandLogo:"assets/images/clients/Harinagar-Sugar-Mills-Ltd.jpg"},
    {BrandName:"Ruby Hall Clinic",BrandLogo:"assets/images/clients/Ruby-Hall-Clinic.jpg"},
    {BrandName:"Jawaharlal Nehru medical college",BrandLogo:"assets/images/clients/Jawaharlal-Nehru-medical-college.jpg"},
    {BrandName:"KLES Hospital & Medical research",BrandLogo:"assets/images/clients/KLES-Hospital-and-Medical-research.jpg"},
    {BrandName:"St. Thomas Hospital",BrandLogo:"assets/images/clients/St-Thomas-Hospital.jpg"},
    {BrandName:"Gogte College of commerce",BrandLogo:"assets/images/clients/Gogte-College-of-commerce.jpg"},
    {BrandName:"Raman Research Institute",BrandLogo:"assets/images/clients/Raman-Research-Institute.jpg"},
    {BrandName:"Indian Institute of Astrophysics",BrandLogo:"assets/images/clients/Indian-Institute-of-Astrophysics.jpg"},
    {BrandName:"Navneet Publications",BrandLogo:"assets/images/clients/Navneet-Publications.jpg"},
    {BrandName:"Titan Industries Ltd",BrandLogo:"assets/images/clients/Titan-Industries-Ltd.jpg"},
    {BrandName:"Mangalore refinery & petrochemicals Ltd",BrandLogo:"assets/images/clients/Mangalore-refinery-and-petrochemicals-Ltd.jpg"},
    {BrandName:"Bharuch Enviro Infrastructure ltd",BrandLogo:"assets/images/clients/Bharuch-Enviro-Infrastructure-ltd.jpg"},
    {BrandName:"Manipal Technologies Ltd",BrandLogo:"assets/images/clients/Manipal-Technologies-Ltd.jpg"},
    {BrandName:"Ultratech Cement Ltd",BrandLogo:"assets/images/clients/Ultratech-Cement-Ltd.jpg"},
    {BrandName:"Jain Group of Industries",BrandLogo:"assets/images/clients/Jain-Group-of-Industries.jpg"},
    {BrandName:"Cipla Ltd",BrandLogo:"assets/images/clients/Cipla-Ltd.jpg"},
    {BrandName:"Torrent Pharma Ltd",BrandLogo:"assets/images/clients/Torrent-Pharma-Ltd.jpg"},
    {BrandName:"Lupin Ltd",BrandLogo:"assets/images/clients/Lupin-Ltd.jpg"},
    {BrandName:"Sandoz Pvt. Ltd",BrandLogo:"assets/images/clients/Sandoz-Pvt-Ltd.jpg"},
    {BrandName:"Hetero Drugs ltd",BrandLogo:"assets/images/clients/Hetero-Drugs-ltd.jpg"},
    {BrandName:"Glenmark Pharma. Ltd",BrandLogo:"assets/images/clients/Glenmark-Pharma-Ltd.jpg"},
    {BrandName:"RPG Life Sciences Ltd",BrandLogo:"assets/images/clients/RPG-Life-Sciences-Ltd.jpg"},
    {BrandName:"Biodeal Pharma. pvt. ltd",BrandLogo:"assets/images/clients/Biodeal-Pharma-pvt-ltd.jpg"},
    {BrandName:"USV Ltd",BrandLogo:"assets/images/clients/USV-Ltd.jpg"},
   ];

}
